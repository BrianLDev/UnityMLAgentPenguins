using UnityEngine;
using MLAgents;
using MLAgents.Sensors;

public class TemplateAgent : Agent
{
    public override void CollectObservations(VectorSensor sensor)
    {
    }

    public override void OnActionReceived(float[] vectorAction)
    {
    }

    public override void OnEpisodeBegin()
    {
    }
}
