using UnityEngine;
using MLAgents;

public class PyramidAcademy : Academy
{
    public override void AcademyReset()
    {
    }

    public override void AcademyStep()
    {
    }
}
